this folder "demo" is available for load a  Data fixtures.
You can Delete this folder if you are in production mode.